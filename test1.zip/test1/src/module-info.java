/**
 * 
 */
/**
 * 
 */
module test1 {
	requires java.desktop;
}